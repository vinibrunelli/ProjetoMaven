package br.com.sauroneye.eventdash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventdashApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventdashApplication.class, args);
	}

}
