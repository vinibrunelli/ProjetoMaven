package br.com.sauroneye.eventdash.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.sauroneye.eventdash.model.Artista;

public interface ArtistaDAO extends CrudRepository<Artista, Integer>{

}
